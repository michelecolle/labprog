#include <iostream>
int d = 7;
int e;
int main()
{
    int a = 5;
    int b = 6;
    int c;
    
    return 0;
}