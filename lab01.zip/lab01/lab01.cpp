#include <iostream>
int d = 7;
int e;
int main()
{
    int a = 5;
    static int b = 6;
    static int c;
    
    return 0;
}